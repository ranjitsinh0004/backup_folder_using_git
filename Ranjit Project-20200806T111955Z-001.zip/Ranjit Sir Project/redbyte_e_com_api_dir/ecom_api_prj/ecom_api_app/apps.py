from django.apps import AppConfig


class EcomApiAppConfig(AppConfig):
    name = 'ecom_api_app'
