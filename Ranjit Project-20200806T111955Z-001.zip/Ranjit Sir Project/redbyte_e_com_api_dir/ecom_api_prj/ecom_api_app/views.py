from django.shortcuts import render
#from rest_framework.views import APIView
from rest_framework.response import Response
from ecom_api_app import serializers
from rest_framework import viewsets
from ecom_api_app.models import (UserRole,UserProfile,ProductName,Order,OrderItem)
from rest_framework.decorators import action
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.settings import api_settings
from rest_framework.decorators import api_view
from rest_framework.response import Response


from rest_framework.viewsets import GenericViewSet
from rest_framework.mixins import CreateModelMixin
from django.contrib.auth import get_user_model
# Create your views here.

class UserRoleViewSet(viewsets.ModelViewSet):
    serializer_class=serializers.UserRoleSerializer
    queryset=UserRole.objects.all()



class UserProfileViewSet(viewsets.ModelViewSet):
    serializer_class=serializers.UserProfileSerializer
    queryset=UserProfile.objects.all()


class ProductNameViewSet(viewsets.ModelViewSet):
    serializer_class=serializers.ProductNameSerializer
    queryset=ProductName.objects.all()



class OrderViewSet(viewsets.ModelViewSet):
    serializer_class=serializers.OrderSerializer
    queryset=Order.objects.all()


class OrderItemViewSet(viewsets.ModelViewSet):
    serializer_class=serializers.OrderItemSerializer
    queryset=OrderItem.objects.all()




class UserLoginApiView(ObtainAuthToken):
    renderer_classes=api_settings.DEFAULT_RENDERER_CLASSES


@api_view(['POST'])
def registration_view(request):
    if request.method=='POST':
        serializer=serializers.RegistrationSerializer(data=request.data)
        data={}
        
        if serializer.is_valid():
            userprofile=serializer.save()
            data['response']="successfully created new user"
            data['first_name'] =userprofile.first_name
            data['last_name'] =userprofile.last_name
            data['email'] =userprofile.email
            data['userrole'] =userprofile.userrole
            data['is_active'] =userprofile.is_active
        else:
            data=serializer.errors
        return Response(data)


class CreateUserView(CreateModelMixin, GenericViewSet):
    queryset = UserProfile.objects.all()
    serializer_class = serializers.UserProfileSerializer




