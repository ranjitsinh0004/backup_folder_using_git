from .models import (UserRole,UserProfile,ProductName,Order,OrderItem)
from rest_framework.serializers import ModelSerializer
from rest_framework import serializers

class UserRoleSerializer(ModelSerializer):
    class Meta:
        model=UserRole
        fields='__all__'

class UserProfileSerializer(ModelSerializer):
    class Meta:
        model=UserProfile
        fields=["id","first_name","last_name","email","userrole","password","is_active"]

        extra_kwargs={
            'password':{
                'write_only':True, #you cannot use password to retrieve the data
            },
        'style':{
            'input_type':'password',
        }
        }

class ProductNameSerializer(ModelSerializer):
    class Meta:
        model=ProductName
        fields='__all__'

class OrderSerializer(ModelSerializer):
    class Meta:
        model=Order
        fields='__all__'

class OrderItemSerializer(ModelSerializer):
    class Meta:
        model=OrderItem
        fields='__all__'


class RegistrationSerializer(ModelSerializer):
    password2=serializers.CharField(style={'input_type':'password'},write_only=True)
    class Meta:
        model=UserProfile
        fields=["id","first_name","last_name","email","userrole","password","password2","is_active"]

        extra_kwargs={
            'password':{
                'write_only':True, #you cannot use password to retrieve the data
            },
        'style':{
            'input_type':'password',
        }
        }
    def save(self):
        userprofile=UserProfile(first_name=self.validated_data['first_name'],
                                last_name=self.validated_data['last_name'],
                                email=self.validated_data['email'], 
                                userrole=self.validated_data['userrole'],
                                password=self.validated_data['password'],
                                is_active=self.validated_data['is_active'],)
        password=self.validated_data['password'],
        password2=self.validated_data['password2']
        if password!=password2:
            raise serializers.ValidationError(
                                                {'password':'password must match'}   
                                                    )
        userprofile.set_password(password)
        userprofile.save()
        return userprofile
