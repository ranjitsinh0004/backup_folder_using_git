from django.contrib import admin
from .models import (UserRole,UserProfile,ProductName,Order,OrderItem,)

# Register your models here.

class UserRoleAdmin(admin.ModelAdmin):
    list_display=["id","title",]
admin.site.register(UserRole,UserRoleAdmin)


class UserAdmin(admin.ModelAdmin):
    list_display=["id","first_name","last_name","email","userrole","password","is_active"]
admin.site.register(UserProfile,UserAdmin)


class ProductNameAdmin(admin.ModelAdmin):
    list_display=["id","product_name","price",]
admin.site.register(ProductName,ProductNameAdmin)

class OrderAdmin(admin.ModelAdmin):
    list_display=["id","user","order_status",]
admin.site.register(Order,OrderAdmin)


class OrderItemAdmin(admin.ModelAdmin):
    list_display=["id","productname","quantity","order"]
admin.site.register(OrderItem,OrderItemAdmin)