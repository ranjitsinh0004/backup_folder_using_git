from django.db import models
from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import AbstractBaseUser
from django.contrib.auth.models import PermissionsMixin
from django.contrib.auth.models import BaseUserManager
from django.conf import settings
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated,AllowAny

UserRole_CHOICES = ( 
        ("customer", "Customer"), 
        ("Vendor", "Vendor"), 
    )

class UserRole(models.Model):
    title = models.CharField( 
        max_length = 20, 
        choices = UserRole_CHOICES, 
        default = 'customer'
        ) 
    
    def __str__(self):
        return self.title

class UserProfileManager(BaseUserManager):
    def create_user(self,email,password,**extra_fields):
        if not email:
            raise ValueError('user must have an emailid')

        last_name=None
        email=self.normalize_email(email)
        user=self.model(email=email,**extra_fields)
        user.set_password(password)


        user.save(using=self._db)
        return user
    
    def create_superuser(self,email,password,**extra_fields):
        user=self.create_user(email,password,**extra_fields)
        user.is_superuser=True
        user.is_staff= True
        user.save(using=self._db)
        return user

class UserProfile(AbstractBaseUser,PermissionsMixin):
    email=models.EmailField(max_length=255,unique=True)
    first_name=models.CharField(max_length=255)
    last_name=models.CharField(max_length=255)
    is_active=models.BooleanField(default=True)
    is_staff=models.BooleanField(default=True)
    userrole=models.ForeignKey('ecom_api_app.UserRole',on_delete=models.CASCADE,null=True,)

    objects=UserProfileManager()

    USERNAME_FIELD='email'
    REQUIRED_FIELDS=['first_name',]
    authentication_classes=[TokenAuthentication,]
    permission_Classes=[AllowAny,]

    '''def get_full_name(self):
        return self.name'''
    def get_short_name(self):
        return self.first_name
    def __str__(self):
        return self.email


class ProductName(models.Model):
    product_name = models.CharField(max_length=56)
    price = models.FloatField()

    def __str__(self):
        return self.product_name


Order_CHOICES = ( 
        ("Order Placed", "Order Placed"), 
        ("Order Accepted", "Order Accepted"), 
        ("Order Cancelled", "Order Cancelled"), 
    )
class Order(models.Model):
    user=models.ForeignKey('UserProfile',on_delete=models.CASCADE,null=True)
    order_status = models.CharField( 
        max_length = 20, 
        choices = Order_CHOICES, 
        default = '1'
        ) 

    def __str__(self):
        return self.user.first_name

class OrderItem(models.Model):
    productname=models.ForeignKey(
        "ProductName", on_delete=models.SET_NULL, unique=True, null=True, blank=True)
    quantity=models.IntegerField()
    #price = models.FloatField()
    order=models.OneToOneField('Order',on_delete=models.SET_NULL,null=True)

    def __str__(self):
        return self.user.first_name






    

    