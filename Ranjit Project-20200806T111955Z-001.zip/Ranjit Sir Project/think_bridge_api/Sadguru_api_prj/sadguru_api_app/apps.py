from django.apps import AppConfig


class SadguruApiAppConfig(AppConfig):
    name = 'sadguru_api_app'
