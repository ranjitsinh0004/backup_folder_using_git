from django.apps import AppConfig


class CrossAppConfig(AppConfig):
    name = 'cross_app'
