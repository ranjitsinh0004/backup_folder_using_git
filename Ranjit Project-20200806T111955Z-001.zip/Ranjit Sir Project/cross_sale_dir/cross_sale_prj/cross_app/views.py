from django.shortcuts import render
from django.views.generic import ListView
from django.views.generic import TemplateView, DetailView
from django.views.generic.edit import CreateView, UpdateView,DeleteView
from django.urls import reverse_lazy
from .models import ClientModel
# Create your views here.
from cross_app.models import ClientModel

class HomeListView(ListView):
    model = ClientModel
    template_name = 'home.html'
    ordering = ['-loan_remained']

class ClientListView(ListView):
    model = ClientModel
    template_name = 'client_list.html'
    ordering = ['-loan_remained']
# https://dev.to/taranjeet/class-based-views-in-django-3bc

class ClientDetailView(DetailView):
    model = ClientModel
    template_name = 'client_detail.html'
    ordering = ['-loan_remained']

class ClientCreateView(CreateView):
    model = ClientModel
    template_name = 'client_create.html'
    fields='__all__'

class ClientUpdateView(UpdateView):
    model = ClientModel
    template_name = 'client_update.html'
    fields='__all__'
    ordering = ['-loan_remained']


class ClientDeleteView(DeleteView):
    model = ClientModel
    template_name = 'client_delete.html'
    success_url = reverse_lazy('home')
    ordering = ['-loan_remained']


'''

####RE

class HomeListView(ListView):
    model = ClientModel
    template_name = 'home.html'
    #ordering = ['-loan_remained']

class REModelListView(ListView):
    model = REModel
    template_name = 're_list.html'
    #ordering = ['-loan_remained']
# https://dev.to/taranjeet/class-based-views-in-django-3bc

class REModelDetailView(DetailView):
    model = REModel
    template_name = 're_detail.html'
    #ordering = ['-loan_remained']

class REModelCreateView(CreateView):
    model = REModel
    template_name = 're_create.html'
    fields='__all__'

class REUpdateView(UpdateView):
    model = REModel
    template_name = 're_update.html'
    fields='__all__'
    #ordering = ['-loan_remained']

class REDeleteView(DeleteView):
    model = REModel
    template_name = 're_delete.html'
    success_url = reverse_lazy('home')
    #ordering = ['-loan_remained']
    '''