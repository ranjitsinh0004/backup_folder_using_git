from django import template
from cross_app.models import ClientModel
register= template.Library()

@register.filter(name='capitalize')
def capitalize_each_word(value):
    '''not needed'''
    '''q1=ClientModel.objects.all().values('name')
    #print(q1)   # <QuerySet [{'name': 'Vanamala Shridharrao Gutte'}, {'name': 'Shridhar Gutte'}]>
    for i in q1:
        for k,v in i.items():
            return (v.title())'''
    result=value.title()
    return result


@register.filter(name='lower')
def lower_each_word(value):
    result=value.lower()
    return result


@register.filter(name='upper')
def upper_each_word(value):
    result=value.upper()
    return result