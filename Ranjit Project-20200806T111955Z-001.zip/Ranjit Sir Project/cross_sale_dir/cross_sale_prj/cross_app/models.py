from django.db import models
# from datetime import datetime,date
import datetime
from phonenumber_field.modelfields import PhoneNumberField
from django.urls import reverse
# ref:https://github.com/stefanfoulis/django-phonenumber-field
# Create your models here.
#class ContactInfo(models.model):
#    pass
#class ClientModel(ContactInfo):

class ClientModel(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    address = models.TextField(max_length=200)
    contact_no = PhoneNumberField(max_length=13, null=False, blank=False, unique=True,
                                  help_text='Add your country code before your contact number e.g:+918999897567')
    email = models.EmailField(null=True, blank=True, unique=True)
    aadhar_no = models.BigIntegerField(unique=True)
    PAN = models.CharField(max_length=20, unique=True)
    bank_acc_no = models.BigIntegerField(unique=True)
    bank_name = models.CharField(max_length=30)
    bank_address = models.CharField(max_length=100)
    IFSC = models.CharField(max_length=30)
    loan_allotted = models.FloatField()
    loan_remained = models.FloatField()
    loan_validity = models.DateField(blank='True',help_text='dd/mm/yy')
    brmodel = models.ForeignKey("BrModel", on_delete=models.SET_NULL, null=True, unique=False)

    def __str__(self):
        return self.name
    def get_absolute_url(self):
        return reverse('client_detail',args=[str(self.id)])


class REModel(models.Model):

    eid = models.CharField(max_length=20, unique=True)
    ename = models.CharField(max_length=200)
    eaddress = models.TextField(max_length=200)
    econtact_no = PhoneNumberField(max_length=13, null=False, blank=False, unique=True,
                                   help_text='Add your country code before your contact number e.g:+918999897567')
    eemail = models.EmailField(null=False, blank=False, unique=True)
    esalary = models.FloatField()
    ebank_acc_no = models.BigIntegerField(unique=True)
    ebank_name = models.CharField(max_length=30)
    ebank_address = models.CharField(max_length=200)
    eIFSC = models.CharField(max_length=30)
    clientmodel = models.ForeignKey(
        "ClientModel", on_delete=models.SET_NULL, unique=True, null=True, blank=True)
    brmodel = models.ForeignKey("BrModel", on_delete=models.CASCADE, null=False, blank=False)

    def __str__(self):
        """String_representation."""
        return self.ename


class BMModel(models.Model):
    """Branch Manager Model."""

    bmid = models.CharField(max_length=20, unique=True)
    bmname = models.CharField(max_length=200)
    bmaddress = models.TextField(max_length=200)
    bmcontact_no = PhoneNumberField(max_length=13, null=False, blank=False, unique=True,
                                    help_text='Add your country code before your contact number e.g:+918999897567')
    bmemail = models.EmailField(null=False, blank=False, unique=True)
    bmsalary = models.FloatField()
    bmbank_acc_no = models.BigIntegerField(unique=True)
    bmbank_name = models.CharField(max_length=30)
    bmbank_address = models.CharField(max_length=200)
    bmIFSC = models.CharField(max_length=30)
    remodel = models.ForeignKey("REModel", on_delete=models.SET_NULL,
                                unique=True, null=True, blank=True)
    brmodel = models.ForeignKey("BrModel", on_delete=models.SET_NULL,
                                unique=True, null=True, blank=True)

    def __str__(self):
        return self.bmname


class BrModel(models.Model):
    brid = models.CharField(max_length=20, unique=True)
    brname = models.CharField(max_length=200)
    braddress = models.TextField(max_length=200)
    brcontact_no = PhoneNumberField(max_length=13, null=False, blank=False, unique=True,
                                    help_text='Add your country code before your contact number e.g:+918999897567')
    bremail = models.EmailField(null=False, blank=False, unique=True)
    brbank_acc_no = models.BigIntegerField(unique=True, blank=True, null=True)
    brbank_name = models.CharField(max_length=30, blank=True, null=True)
    brbank_address = models.CharField(max_length=200, blank=True, null=True)
    brIFSC = models.CharField(max_length=30, blank=True, null=True)

    def __str__(self):
        return self.brname


class HOModel(models.Model):
    hoid = models.CharField(max_length=20, unique=True)
    honame = models.CharField(max_length=200)
    hoaddress = models.TextField(max_length=200)
    hocontact_no = PhoneNumberField(max_length=13, null=False, blank=False, unique=True,
                                    help_text='Add your country code before your contact number e.g:+918999897567')
    hoemail = models.EmailField()
    hobank_acc_no = models.BigIntegerField(unique=True, blank=True, null=True)
    hobank_name = models.CharField(max_length=30, blank=True, null=True)
    hobank_address = models.CharField(max_length=200, blank=True, null=True)
    hoIFSC = models.CharField(max_length=30)
    brmodel = models.ForeignKey("BrModel", on_delete=models.SET_NULL,
                                unique=True, null=True, blank=True)

    def __str__(self):
        return self.honame
# fake migrations:
# https://docs.djangoproject.com/en/3.0/topics/migrations/
# https://riptutorial.com/django/example/15978/fake-migrations
