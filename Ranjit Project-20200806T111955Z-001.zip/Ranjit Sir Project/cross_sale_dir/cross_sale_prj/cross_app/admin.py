from django.contrib import admin
from .models import ClientModel, REModel, BMModel, BrModel, HOModel

# Register your models here.
admin.site.register(ClientModel)
admin.site.register(REModel)
admin.site.register(BMModel)
admin.site.register(BrModel)
admin.site.register(HOModel)
