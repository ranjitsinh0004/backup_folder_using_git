from django.db import models

# Create your models here.
class Student(models.Model):
    name=models.CharField(max_length=40)
    roll_no=models.CharField(max_length=10)
    dob=models.DateField(auto_now_add=False)
    branch=models.CharField(max_length=20)
    contact_no=models.IntegerField()
    email=models.EmailField()
    address=models.TextField(max_length=100)
    def __str__(self):
        return self.name
class StudentClass(models.Model):
    class_name=models.CharField(max_length=10)
    student = models.ForeignKey(Student, on_delete = models.CASCADE)
    def __str__(self):
        return self.class_name
class Subjects(models.Model):
    sub_name=models.CharField(max_length=15)
    student = models.ManyToManyField(Student, blank=True)

    def __str__(self):
        return self.sub_name
