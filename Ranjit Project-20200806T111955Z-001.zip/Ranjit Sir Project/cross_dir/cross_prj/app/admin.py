from django.contrib import admin
from .models import Student,StudentClass,Subjects

# Register your models here.
class StudentAdmin(admin.ModelAdmin):
    list_display=['name','roll_no','dob','branch','contact_no','email','address']
admin.site.register(Student,StudentAdmin)

class StudentClassAdmin(admin.ModelAdmin):
    list_display=['class_name',]
admin.site.register(StudentClass,StudentClassAdmin)

class SubjectsAdmin(admin.ModelAdmin):
    list_display=['sub_name',]
admin.site.register(Subjects,SubjectsAdmin)
